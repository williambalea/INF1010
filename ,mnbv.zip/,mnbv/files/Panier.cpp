/********************************************
* Titre: Travail pratique #2 - Panier.cpp
* Date: 25 janvier 2018
* Auteur: Mohammed Esseddik BENYAHIA & Timothée CHAUVIN
*******************************************/

#include "Panier.h"

Panier::Panier(int capacite) :
	capaciteContenu_{ capacite },
	nombreContenu_{ 0 },
	//contenuPanier_{ new Produit *[capaciteContenu_] },
	totalAPayer_{ 0 }
{
}

Panier::~Panier()
{
}

// methodes d'accès
vector<Produit*> Panier::obtenirContenuPanier()const
{
	return contenuPanier_;
}

int Panier::obtenirNombreContenu() const
{
	return nombreContenu_;
}

double Panier::obtenirTotalApayer() const
{
	return totalAPayer_;
}

void Panier::modifierTotalAPayer(double totalAPayer)
{
	totalAPayer_ = totalAPayer;
}

// méthodes de modification

// autres méthodes
void Panier::ajouter(Produit * prod)
{
	contenuPanier_.push_back(prod);
	/*if (nombreContenu_ >= capaciteContenu_)
	{
		Produit ** temp;
		capaciteContenu_ *= 2;
		temp = new Produit*[capaciteContenu_];
		for (int i = 0; i < nombreContenu_; i++)
			temp[i] = contenuPanier_[i];
		delete contenuPanier_;
		contenuPanier_ = temp;
	}
	contenuPanier_[nombreContenu_++] = prod;
	totalAPayer_ += prod->obtenirPrix();*/
}

void Panier::livrer()
{
	for (unsigned i = 0; i < contenuPanier_.size(); i++) {
		 contenuPanier_.pop_back();
	}
	/*delete[]contenuPanier_;
	nombreContenu_ = 0;
	totalAPayer_ = 0;
	contenuPanier_ = new Produit *[capaciteContenu_];*/
}

Produit * Panier::trouverProduitPlusCher()
{
	// TODO: Implementez la methode
	Produit produit;
	Produit *produitMax = &produit;

	for (unsigned i = 0; i < contenuPanier_.size();i++){
		if (produitMax->operator<(*contenuPanier_[i])){
			produitMax = contenuPanier_[i];
		}
	}
	return produitMax;
}

//void Panier::afficher() const
//{
//	for (int i = 0; i < nombreContenu_; i++)
//		contenuPanier_[i]->afficher();
//
//	cout << "----> total a payer : " << totalAPayer_ << endl;
//}

ostream& operator << (ostream& sortie, Panier panier)
{
	for (unsigned i = 1; i < panier.contenuPanier_.size(); i++) {

		sortie << "----> " << *panier.contenuPanier_[i] << endl;  //affichage nom,ref,prix??
	}
	//sortie << "----> total a payer : " << panier.totalAPayer_ << endl;
	return sortie;

}
