/********************************************
* Titre: Travail pratique #2 - Rayon.cpp
* Date: 25 janvier 2018
* Auteur: Timoth�e CHAUVIN
*******************************************/

#include "Rayon.h"

Rayon::Rayon(const string& cat) :
	categorie_{ cat },
	tousProduits_{ nullptr },
	capaciteProduits_{ 0 },
	nombreProduits_{ 0 }
{
}

//Rayon::~Rayon()
//{
//	if (tousProduits_ != nullptr)
//		delete[] tousProduits_;
//}

// Methodes d'acces
string Rayon::obtenirCategorie() const
{
	return categorie_;
}

vector<Produit*> Rayon::obtenirTousProduits() const
{
	return tousProduits_;
}

int Rayon::obtenirCapaciteProduits() const
{
	return capaciteProduits_;
}

// Methodes de modification
void Rayon::modifierCategorie(const string& cat)
{
	categorie_ = cat;
}

void Rayon::ajouterProduit(Produit* produit)
{
	tousProduits_.push_back(produit);
		
		//nombreProduits_++;
	
}

//void Rayon::afficher() const
//{
//	cout << "Le rayon " << categorie_ << ": " << endl;
//	for (int i = 0; i < nombreProduits_; i++) {
//		cout << "----> ";
//		tousProduits_[i]->afficher();
//	}
//}

ostream& operator << (ostream& sortie, Rayon rayon)
{
	sortie << "Le rayon " << rayon.categorie_ << ": " << endl;
	
		for (unsigned i = 1; i < rayon.tousProduits_.size() ; i++) {
			
			sortie << "----> " << *rayon.tousProduits_[i] << endl; //affichage nom,ref,prix??
		}
	return sortie;

}

Rayon& Rayon::operator+=(Produit &produit) 
{
	ajouterProduit(&produit);
	return *this;

}

int Rayon::compterDoublons(const Produit& produit)
{
	int compteur = 0;
	for (int i = 1; i < tousProduits_.size(); i++){
		if (tousProduits_[i]->operator==(produit))
			compteur++;
	}
	return compteur;
}